Sitio web estático para BAS - Backoffice Apoyo y Soluciones SpA
Generado automáticamente. Estructura:
- index.html
- styles.css
- assets/Logo_BAS_Transparente.png
- assets/favicon.png

Instrucciones rápidas para GitHub Pages:
1. Crea un repositorio público llamado 'backoffice-bas' (o el nombre que prefieras).
2. Sube el contenido del folder bas_site al repo (Add file -> Upload files).
3. En Settings -> Pages, selecciona la rama 'main' (o la rama por defecto) y la carpeta / (root) como source.
4. Publica y espera unos minutos. La URL será https://tuusuario.github.io/backoffice-bas/

Reemplaza assets/Logo_BAS_Transparente.png por tu logo oficial si lo deseas.
